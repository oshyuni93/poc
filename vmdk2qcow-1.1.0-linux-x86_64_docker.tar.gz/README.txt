vmdk2qcow 1.1.0 - Standalone Linux x86_64 binary
Requirements: qemu-utils (qemu-img), optional qemu-system-x86_64 for test-boot

Install:
  sudo mv vmdk2qcow /usr/local/bin/ && sudo chmod +x /usr/local/bin/vmdk2qcow

Examples:
  vmdk2qcow inspect ./vm.ova
  vmdk2qcow pipeline ./vm.ova -o ./out --base-url http://HOST:8080
  vmdk2qcow pipeline ./rocky.ova -o ./out --os rocky --test-boot
  vmdk2qcow serve ./out --port 8080
